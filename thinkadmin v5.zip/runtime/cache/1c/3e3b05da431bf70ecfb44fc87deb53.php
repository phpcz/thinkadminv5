<?php
//000000000000
 exit();?>
/www/wwwroot/thinkadmin.phpcz.top/runtime/cache/c0/14eb3ce62fb477433e2c14d42941d3.php