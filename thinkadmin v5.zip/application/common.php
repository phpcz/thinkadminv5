<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/20
 * Time: 10:39
 */


if (!function_exists('hideEmail')) {
    /**
     * 邮箱用*号隐藏
     * @param $email
     * @return string
     */
    function hideEmail($email)
    {
        $prefix_email = substr($email, 0, strrpos($email, '@'));
        $suffix_email = substr($email, strrpos($email, '@'));
        $count = strlen($prefix_email);
        if ($count > 3) {
            $start = substr($prefix_email, 0, 2);
            $end = substr($prefix_email, -1);
        } else {
            $start = substr($prefix_email, 0, 1);
            $end = '';
        }
        return $start . '****' . $end . $suffix_email;
    }
}

if (!function_exists('hidePhonae')) {
    /**
     * 手机用*号隐藏
     * @param $phone
     * @return mixed
     */
    function hidePhone($phone)
    {
        $phone = substr_replace($phone, '****', 3, 4);
        return $phone;
    }
}

if (!function_exists('splitStr')) {
    /**
     * 字符串中文截取
     * @param $str  需要截取的字符串
     * @param int $length 截取长度
     * @param string $code 字符编码格式
     * @return string   经过截取后的字符串
     */
    function splitStr($str, $length = 50, $code = "utf-8")
    {
        if (mb_strlen($str, $code) > $length) {
            return mb_substr($str, 0, $length, $code) . '...';
        } else {
            return $str;
        }
    }
}

if (!function_exists('strLine')) {
    /**
     * 把文本中的换行空格替换为<br> &nbsp
     * @param $str  需要替换的字符串
     * @return mixed  经过替换过得字符串
     */
    function strLine($str)
    {
        $str = str_replace(["\r\n", "\r", "\n"], '<br>', $str);
        $str = str_replace(' ', "&nbsp", $str);
        return $str;
    }
}

if (!function_exists('checkImages')) {
    /**
     * 检查图片地址是否正确
     * @param $images
     * @return mixed
     */
    function checkImage($images)
    {
        if (!is_array($images))
        {
            $images = explode('|',$images);
        }

        foreach ($images as $v)
        {
            if (!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/', $v))
            {
                return false;
            }
        }

        return true;
    }
}

if (!function_exists('getConfig')) {
    /**
     * 获取config配置
     * @param $name 配置名称
     * @param string $value 配置值
     * @return mixed
     */
    function getConfig($name,$value = '')
    {
        if ($value)
        {
            return config($name)[$value];
        }

        return config($name);
    }
}

if (!function_exists('format_bytes')) {
    /**
     * 格式化字节大小
     * @param  number $size 字节数
     * @param  string $delimiter 数字和单位分隔符
     * @return string  格式化后的带单位的大小
     */
    function format_bytes($size, $delimiter = '')
    {
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
        for ($i = 0; $size >= 1024 && $i < 5; $i++) $size /= 1024;
        return round($size, 2) . $delimiter . $units[$i];
    }
}
